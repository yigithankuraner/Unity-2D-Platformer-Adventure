using UnityEngine;

public class FrogBullet : MonoBehaviour
{
    public float speed = 10f;
    public float lifeTime = 3f;
    public int damage = 1;

    void Start()
    {
        GetComponent<Rigidbody2D>().linearVelocity = transform.right * speed;
        Destroy(gameObject, lifeTime);
    }

    void OnTriggerEnter2D(Collider2D hitInfo)
    {
        // Enemy'ye çarpıyorsa yok say
        if (hitInfo.CompareTag("Enemy"))
            return;

        // Player'a çarptıysa hasar ver
        if (hitInfo.CompareTag("Player"))
        {
            PlayerHealth playerHealth = hitInfo.GetComponent<PlayerHealth>();

            if (playerHealth != null)
            {
                playerHealth.TakeDamage(damage);
            }
        }

        // Her durumda mermiyi yok et
        Destroy(gameObject);
    }
}

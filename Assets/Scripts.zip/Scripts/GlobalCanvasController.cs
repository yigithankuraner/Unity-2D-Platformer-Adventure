using UnityEngine;

public class GlobalCanvasController : MonoBehaviour
{
    public static GlobalCanvasController Instance;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
